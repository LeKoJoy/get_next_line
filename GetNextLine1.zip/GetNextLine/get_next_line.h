/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anhoncha <anhoncha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 11:12:08 by andrii            #+#    #+#             */
/*   Updated: 2024/12/04 17:12:16 by anhoncha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H
# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 42
# endif
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>


static void free_and_clean(char **ptr);
static char *allocate_and_copy(char *buffer, size_t total_size,
	char *temp_buffer, ssize_t bytes_read);
char *get_next_line(int fd);
int		ft_strlen(char *c);
char	*ft_substr(char const *s, unsigned int start, size_t len);
char	*ft_strjoin(char const *s1, char const *s2);
size_t	ft_strlcpy(char *str1, const char *str2, size_t c);
char	*ft_strchr(const char *str, int c);
#endif
