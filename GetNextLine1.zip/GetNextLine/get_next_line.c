/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anhoncha <anhoncha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 11:07:29 by andrii            #+#    #+#             */
/*   Updated: 2024/12/05 17:01:38 by anhoncha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char buffer_process(char *stat_buffer, char temp_buffer);

char *ft_strchr_before(const char *str, int c)
{
    int i = 0;
    char *result;

    // Проходим по строке до конца или до нахождения символа
    while (str[i])
    {
        if (str[i] == (char)c)
        {
            // Выделяем память под новую строку (до символа)
            result = (char *)malloc(i + 1);  // +1 для '\0'
            if (!result)
                return (NULL);  // Проверка на успешное выделение памяти

            // Копируем символы до найденного символа
            for (int j = 0; j < i; j++)
                result[j] = str[j];

            result[i] = '\0';  // Добавляем нуль-терминатор
            return result;
        }
        i++;
    }

    // Если символ не найден, возвращаем копию всей строки
    result = (char *)malloc(i + 1);
    if (!result)
        return (NULL);

    for (int j = 0; j < i; j++)
        result[j] = str[j];

    result[i] = '\0';
    return result;
}

char	*get_next_line(int fd)
{
	static char		*stat_buffer;
	char			*temp_buffer;
	char			*temp_reader;
	size_t			total_size;
	ssize_t			bytes_read;

	if (fd < 0 || BUFFER_SIZE == 0 || read(fd, 0, 0) < 0)
		return (NULL);
	temp_buffer = NULL;
	total_size = 0;
	bytes_read = 0;
	while (bytes_read > 0)
	{
		temp_buffer = ft_strjoin(stat_buffer, temp_buffer);
		bytes_read = read(fd, temp_reader, BUFFER_SIZE);
		total_size += bytes_read;
		temp_buffer = ft_strjoin(temp_buffer, temp_reader);
		stat_buffer = ft_strchr(temp_buffer, '\n');
		temp_buffer = ft_strchr_before(temp_buffer, '\n')
		if(!stat_buffer)
			break;
	}
	temp_buffer[total_size] = '\0';
	return (temp_buffer);
}

int main(void)
{
	char *filename = "text.txt";
	char *str;
	int fd = open(filename, O_RDWR);

	str = get_next_line(fd);
	printf("%s", str);
	return 0;
}