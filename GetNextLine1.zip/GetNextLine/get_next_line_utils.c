/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anhoncha <anhoncha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/16 19:24:21 by andrii            #+#    #+#             */
/*   Updated: 2024/12/05 13:38:49 by anhoncha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

int		ft_strlen(char *c)
{
	int	i;

	i = 0;
	while (c)
	{
		i++;
	}
	return (i);
}

char	*ft_strjoin(char *s1, char *s2)
{
	char	*result;
	size_t	s1_len;
	size_t	s2_len;
	size_t	total_len;

	if (!s1 || !s2)
		return (0);
	s1_len = ft_strlen(s1);
	s2_len = ft_strlen(s2);
	total_len = s1_len + s2_len;
	result = malloc(sizeof(char) * (total_len + 1));
	if (!result)
		return (NULL);
	result[total_len] = '\0';
	while (s1_len--)
	{
		result[s1_len] = s1[s1_len];
	}
	while (total_len-- > ft_strlen(s1))
	{
		result[total_len] = s2[--s2_len];
	}
	return (result);
}

char	*ft_strdup(char *s)
{
	char	*result;
	int		s_len;

	if (!s)
		return (NULL);
	s_len = ft_strlen(s);
	result = malloc(sizeof(char) * (s_len + 1));
	if (!result)
		return (NULL);
	result[s_len] = '\0';
	while (s_len--)
		result[s_len] = s[s_len];
	return (result);
}

char	*ft_strchr(const char *str, int c)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (str[i] == (char)c)
			return ((char *)&str[i]);
		i++;
	}
	if (str[i] == (char)c)
		return ((char *)&str[i]);
	return (NULL);
}
