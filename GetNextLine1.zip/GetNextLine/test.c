# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 42
# endif

int		ft_strlen(const char *c)
{
	int	i;

	i = 0;
	while (c[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*ft_strchr(const char *str, int c)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (str[i] == (char)c)
			return ((char *)&str[i]);
		i++;
	}
	if (str[i] == (char)c)
		return ((char *)&str[i]);
	return (NULL);
}

char *ft_strchr_before(const char *str, int c)
{
    int i = 0;
    char *result;

    // Проходим по строке до конца или до нахождения символа
    while (str[i])
    {
        if (str[i] == (char)c)
        {
            // Выделяем память под новую строку (до символа)
            result = (char *)malloc(i + 1);  // +1 для '\0'
            if (!result)
                return (NULL);  // Проверка на успешное выделение памяти

            // Копируем символы до найденного символа
            for (int j = 0; j < i; j++)
                result[j] = str[j];

            result[i] = '\0';  // Добавляем нуль-терминатор
            return result;
        }
        i++;
    }

    // Если символ не найден, возвращаем копию всей строки
    result = (char *)malloc(i + 1);
    if (!result)
        return (NULL);

    for (int j = 0; j < i; j++)
        result[j] = str[j];

    result[i] = '\0';
    return result;
}

int	main(void)
{
/* 	int		fd;
	char	*filename = "text.txt";
	char	str[1024];
	int		bytes_read;
	int		total_size;

	total_size = 0;
	bytes_read = 0;
	fd = open(filename, O_RDWR);
	if(fd == -1)
	{
		printf("\nError Opening File!!\n");
		exit(1);
	}
	else
	{
		printf("\nFile %s opened sucessfully!\n", filename);
	}
	bytes_read = read(fd, str, BUFFER_SIZE);
	printf("%d\n", bytes_read);
	printf("%s\n", str); */
	char	str[20] = "WTF IS A \nKOLIMETOR?";
	printf("%s\n", ft_strchr_before(str, '\n'));
	return (0);
}