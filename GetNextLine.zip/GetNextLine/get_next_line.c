/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 11:07:29 by andrii            #+#    #+#             */
/*   Updated: 2024/11/13 18:09:24 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static char		*buffer_alc(size_t volume)
{
	char	*buffer;

	buffer = malloc((volume + 1) * sizeof(char));
	if (!buffer)
		return (NULL);
	return (buffer);
}

static char		*buffill(char *buffer, char *str, int fd)
{

}

char *get_next_line(int fd)
{
    static char		*tstr;
	char			*line;
	char			*buff;

	if (fd < 0 || BUFFER_SIZE <= 0 || read(fd, 0, 0) < 0)
	{
		return (NULL);
	}
	buff = buffer_alc(BUFFER_SIZE);
	line = buffill(fd, tstr, buff);
	free(buff);
	buff = NULL;
	if (!line)
		return (NULL);
	tstr = out_line(line);
	return (line);
}
