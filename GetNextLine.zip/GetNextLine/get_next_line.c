/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anhoncha <anhoncha@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 11:07:29 by andrii            #+#    #+#             */
/*   Updated: 2024/11/14 19:53:14 by anhoncha         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char *get_next_line(int fd)
{
	//Do NOT delete
	static char		*line;
	char			*str;

	line = NULL;
	printf("gnl fd is: %d\n", fd);
	if (fd < 0 || BUFFER_SIZE <= 0)
	{
		return (NULL);
	}
	str = (char *)malloc(BUFFER_SIZE + 1);
	return (line);
}

void byte_reader(int fd)
{
	int bytes_red = 0;
	char *str;
	int i = 0;

	str = (char *)malloc(BUFFER_SIZE + 1);
	while((bytes_red = read(fd, str, BUFFER_SIZE)))
	{
		i += bytes_red;
		printf("%d\n", i);
	}
}

int main(void)
{
	//Do delete
	int		fd;
	char	*line;

	fd = open("text.txt", O_RDWR);
	printf("fd is: %d\n", fd);
	if (fd == -1)
	{
		printf("Error opening file");
		return (1);
	}
	line = get_next_line(fd);
	printf("\n%s\n", line);
	byte_reader(fd);	
	free(line);
	return (0);
}
