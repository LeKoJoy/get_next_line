/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 11:07:29 by andrii            #+#    #+#             */
/*   Updated: 2024/11/17 10:39:49 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char *get_next_line(int fd)
{
    static char		temp_buffer[BUFFER_SIZE];
	char			*buffer;
	size_t			total_size;
	ssize_t			bytes_read;

	if (fd < 0 || BUFFER_SIZE == 0 || read(fd, 0, 0) < 0)
		return (NULL);
	buffer = NULL;
	total_size = 0;
	while ((bytes_read = read(fd, temp_buffer, BUFFER_SIZE)) > 0)
	{
		buffer = allocate_and_copy(buffer, total_size, temp_buffer, bytes_read);
		if(!buffer)
			return (NULL);
		total_size += bytes_read;
	}
	if (bytes_read < 0)
		free_and_clean(&buffer);
	else if (buffer)
		buffer[total_size] = '\0';
	return (buffer);
} 

int main(void)
{
	char *filename = "text.txt";
	char *str;
	int fd = open(filename, O_RDWR);

	str = get_next_line(fd);
	printf("%s", str);
	return 0;
}