/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: andrii <andrii@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/16 19:24:21 by andrii            #+#    #+#             */
/*   Updated: 2024/11/17 10:36:39 by andrii           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static void free_and_clean(char **ptr)
{
	if (*ptr)
	{
		free(*ptr);
		*ptr = NULL;
	}
}

static char *allocate_and_copy(char *buffer, size_t total_size,
	char *temp_buffer, ssize_t bytes_read)
{
	char	*new_buffer;
	size_t	i;

	new_buffer = malloc(total_size + bytes_read + 1);
	if (!new_buffer)
	{
		free_and_clean(&buffer);
		return (NULL);
	}
	i = 0;
	while (i < total_size)
	{
		new_buffer[i] = buffer[i];
		i++;
	}
	i = 0;
	while (i < (size_t)bytes_read)
	{
		new_buffer[total_size + i] = temp_buffer[i];
		i++;
	}
	return (new_buffer);
}